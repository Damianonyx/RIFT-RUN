import { n as INITIAL_SNAP } from "./routes-CX81ekbU.mjs";
import { C as Scene, S as SRGBColorSpace, T as Vector3, _ as PerspectiveCamera, a as CircleGeometry, b as Points, c as Float32BufferAttribute, d as HemisphereLight, f as MathUtils, g as OctahedronGeometry, h as MeshStandardMaterial, i as BufferGeometry, l as FogExp2, m as MeshBasicMaterial, n as BoxGeometry, o as Color, p as Mesh, r as BufferAttribute, s as DirectionalLight, t as WebGLRenderer, u as Group, v as PlaneGeometry, w as SphereGeometry, x as PointsMaterial, y as PointLight } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-Q4oWkSUX.js
/** Procedural SFX via Web Audio. Unlock on the first user gesture. */
var GameAudio = class {
	ctx = null;
	master = null;
	sfx = null;
	drone = null;
	droneGain = null;
	muted = false;
	unlock() {
		if (!this.ctx) {
			const Ctx = window.AudioContext || window.webkitAudioContext;
			this.ctx = new Ctx({ latencyHint: "interactive" });
			this.master = this.ctx.createGain();
			this.sfx = this.ctx.createGain();
			this.sfx.gain.value = .7;
			this.sfx.connect(this.master);
			this.master.connect(this.ctx.destination);
			this.master.gain.value = this.muted ? 0 : .85;
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	setMuted(muted) {
		this.muted = muted;
		if (this.master && this.ctx) this.master.gain.setTargetAtTime(muted ? 0 : .85, this.ctx.currentTime, .03);
	}
	resume() {
		if (this.ctx?.state === "suspended") this.ctx.resume();
	}
	jump() {
		this.blip(420, 180, .09, "square", .07);
	}
	lane() {
		this.blip(220, 140, .06, "triangle", .04);
	}
	coin(combo) {
		const bump = Math.min(combo, 6) * 40;
		this.blip(660 + bump, 990 + bump, .11, "sine", .09);
		this.blip(880 + bump, 1320 + bump, .08, "triangle", .04);
	}
	crash() {
		const ctx = this.ctx;
		const sfx = this.sfx;
		if (!ctx || !sfx) return;
		const dur = .28;
		const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * dur), ctx.sampleRate);
		const data = buffer.getChannelData(0);
		for (let i = 0; i < data.length; i++) {
			const t = i / data.length;
			data[i] = (Math.random() * 2 - 1) * (1 - t) * (1 - t);
		}
		const src = ctx.createBufferSource();
		src.buffer = buffer;
		const filter = ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.setValueAtTime(900, ctx.currentTime);
		filter.frequency.exponentialRampToValueAtTime(120, ctx.currentTime + dur);
		const g = ctx.createGain();
		g.gain.setValueAtTime(1e-4, ctx.currentTime);
		g.gain.exponentialRampToValueAtTime(.55, ctx.currentTime + .01);
		g.gain.exponentialRampToValueAtTime(1e-4, ctx.currentTime + dur);
		src.connect(filter);
		filter.connect(g);
		g.connect(sfx);
		src.start();
		src.stop(ctx.currentTime + dur + .02);
		this.blip(140, 50, .22, "sawtooth", .08);
	}
	startDrone() {
		this.stopDrone();
		const ctx = this.ctx;
		const sfx = this.sfx;
		if (!ctx || !sfx) return;
		const osc = ctx.createOscillator();
		const g = ctx.createGain();
		osc.type = "sine";
		osc.frequency.value = 72;
		g.gain.setValueAtTime(1e-4, ctx.currentTime);
		g.gain.exponentialRampToValueAtTime(.035, ctx.currentTime + .6);
		osc.connect(g);
		g.connect(sfx);
		osc.start();
		this.drone = osc;
		this.droneGain = g;
	}
	stopDrone() {
		if (!this.drone || !this.ctx || !this.droneGain) return;
		const osc = this.drone;
		this.droneGain.gain.setTargetAtTime(1e-4, this.ctx.currentTime, .08);
		osc.stop(this.ctx.currentTime + .4);
		this.drone = null;
		this.droneGain = null;
	}
	dispose() {
		this.stopDrone();
		this.ctx?.close();
		this.ctx = null;
		this.master = null;
		this.sfx = null;
	}
	blip(from, to, dur, type, vol) {
		const ctx = this.ctx;
		const sfx = this.sfx;
		if (!ctx || !sfx) return;
		const osc = ctx.createOscillator();
		const g = ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(from, ctx.currentTime);
		osc.frequency.exponentialRampToValueAtTime(Math.max(40, to), ctx.currentTime + dur);
		g.gain.setValueAtTime(1e-4, ctx.currentTime);
		g.gain.exponentialRampToValueAtTime(vol, ctx.currentTime + .012);
		g.gain.exponentialRampToValueAtTime(1e-4, ctx.currentTime + dur);
		osc.connect(g);
		g.connect(sfx);
		osc.start();
		osc.stop(ctx.currentTime + dur + .03);
	}
};
var SEG_LEN = 18;
var SEG_COUNT = 12;
var LANES = [
	-2.25,
	0,
	2.25
];
var BASE_SPEED = 16;
var MAX_SPEED = 34;
var SPEED_RAMP = .24;
var FIXED = 1 / 60;
var JUMP_V = 8.8;
var GRAVITY = 24;
var LANE_TIME = .16;
var STORAGE_KEY = "rift-run-v1";
var RECYCLE_Z = 22;
var _world = new Vector3();
function easeOutCubic(t) {
	const u = 1 - t;
	return 1 - u * u * u;
}
function expDamp(current, target, lambda, dt) {
	return current + (target - current) * (1 - Math.exp(-lambda * dt));
}
function randLane() {
	return Math.floor(Math.random() * 3) - 1;
}
function otherLanes(open) {
	return [
		-1,
		0,
		1
	].filter((l) => l !== open);
}
function readBest() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return 0;
		const parsed = JSON.parse(raw);
		return typeof parsed.best === "number" ? parsed.best : 0;
	} catch {
		return 0;
	}
}
function writeBest(best) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify({
			v: 1,
			best
		}));
	} catch {}
}
function makeRenderer(canvas, mobile) {
	const attempts = [{
		canvas,
		antialias: !mobile,
		alpha: false,
		depth: true,
		stencil: false,
		powerPreference: "default",
		failIfMajorPerformanceCaveat: false
	}, {
		canvas,
		antialias: false,
		alpha: false,
		depth: true,
		powerPreference: "low-power",
		failIfMajorPerformanceCaveat: false
	}];
	for (const params of attempts) try {
		const renderer = new WebGLRenderer(params);
		if (renderer.getContext()) return renderer;
		renderer.dispose();
	} catch {}
	return null;
}
function mat(color, extras = {}) {
	return new MeshStandardMaterial({
		color,
		roughness: .62,
		metalness: .08,
		...extras
	});
}
var RunnerGame = class {
	canvas;
	onChange;
	renderer = null;
	scene = new Scene();
	camera;
	audio = new GameAudio();
	ro = null;
	running = false;
	failed = false;
	reduceMotion = false;
	mobile = false;
	state = "start";
	speed = 0;
	distance = 0;
	coins = 0;
	combo = 0;
	comboTimer = 0;
	score = 0;
	best = 0;
	muted = false;
	playerRoot = new Group();
	courier = new Group();
	shadowBlob = null;
	parts = null;
	lane = 0;
	fromLane = 0;
	toLane = 0;
	laneT = 1;
	queued = 0;
	hop = 0;
	vy = 0;
	grounded = true;
	coyote = 0;
	jumpBuf = 0;
	runPhase = 0;
	playerX = 0;
	keys = /* @__PURE__ */ new Set();
	injected = /* @__PURE__ */ new Set();
	prevHeld = /* @__PURE__ */ new Set();
	steerInject = 0;
	prevSteer = 0;
	pointers = /* @__PURE__ */ new Map();
	segments = [];
	lastHazard = false;
	cratePool = [];
	wallPool = [];
	orbPool = [];
	particles = [];
	iceSpark;
	rustSpark;
	sun = null;
	acc = 0;
	time = 0;
	trauma = 0;
	hitstop = 0;
	lastEmit = "";
	geos = [];
	mats = [];
	onKeyDown = (e) => this.handleKey(e, true);
	onKeyUp = (e) => this.handleKey(e, false);
	onBlur = () => {
		this.keys.clear();
	};
	onVis = () => {
		if (document.hidden) this.keys.clear();
		this.audio.resume();
	};
	onPointerDown = (e) => this.ptrDown(e);
	onPointerUp = (e) => this.ptrUp(e);
	onPointerCancel = (e) => {
		this.pointers.delete(e.pointerId);
	};
	onResize = () => this.resize();
	constructor(canvas, onChange) {
		this.canvas = canvas;
		this.onChange = onChange;
		this.best = readBest();
		this.mobile = window.matchMedia("(pointer: coarse)").matches;
		this.reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		this.camera = new PerspectiveCamera(55, 1, .1, 240);
		this.camera.position.set(0, 3.7, 8.2);
		try {
			this.renderer = makeRenderer(canvas, this.mobile);
		} catch {
			this.failed = true;
			this.emit();
			return;
		}
		if (!this.renderer) {
			this.failed = true;
			this.emit();
			return;
		}
		try {
			const renderer = this.renderer;
			renderer.outputColorSpace = SRGBColorSpace;
			renderer.toneMapping = 4;
			renderer.toneMappingExposure = 1.08;
			renderer.setClearColor(658450, 1);
			renderer.shadowMap.enabled = !this.mobile;
			renderer.shadowMap.type = 2;
			renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, this.mobile ? 1.25 : 2));
			this.buildWorld();
			this.buildPlayer();
			this.buildParticles();
			this.layoutSegments(false);
			this.resize();
			this.bind();
			this.hookControlsTest();
			this.running = true;
			this.emit();
			renderer.setAnimationLoop((t) => this.frame(t));
			requestAnimationFrame(() => this.resize());
		} catch {
			this.failed = true;
			this.renderer?.dispose();
			this.renderer = null;
			this.emit();
		}
	}
	start() {
		if (this.failed || this.state === "playing") return;
		try {
			this.audio.unlock();
		} catch {}
		this.resetRun(true);
		this.state = "playing";
		try {
			this.audio.startDrone();
		} catch {}
		this.emit();
	}
	setMuted(muted) {
		this.muted = muted;
		this.audio.setMuted(muted);
		this.emit();
	}
	toggleMuted() {
		this.setMuted(!this.muted);
	}
	queueLane(dir) {
		this.trySwitch(dir);
	}
	queueJump() {
		this.jumpBuf = .14;
	}
	dispose() {
		this.running = false;
		this.renderer?.setAnimationLoop(null);
		this.unbind();
		this.audio.dispose();
		this.ro?.disconnect();
		this.scene.traverse((obj) => {
			const mesh = obj;
			if (mesh.isMesh) mesh.geometry = mesh.geometry;
		});
		for (const g of this.geos) g.dispose();
		for (const m of this.mats) m.dispose();
		this.renderer?.dispose();
		if (window.__controlsTest) delete window.__controlsTest;
	}
	trackGeo(g) {
		this.geos.push(g);
		return g;
	}
	trackMat(m) {
		this.mats.push(m);
		return m;
	}
	buildWorld() {
		this.scene.fog = new FogExp2(856600, .011);
		this.scene.background = new Color(658450);
		const hemi = new HemisphereLight(9347252, 1710102, .72);
		this.scene.add(hemi);
		const sun = new DirectionalLight(16773596, 1.15);
		sun.position.set(10, 22, 8);
		sun.castShadow = !this.mobile;
		sun.shadow.mapSize.set(1024, 1024);
		sun.shadow.camera.near = 2;
		sun.shadow.camera.far = 70;
		sun.shadow.camera.left = -18;
		sun.shadow.camera.right = 18;
		sun.shadow.camera.top = 18;
		sun.shadow.camera.bottom = -12;
		sun.shadow.bias = -8e-4;
		this.scene.add(sun);
		this.scene.add(sun.target);
		sun.target.position.set(0, 0, -12);
		this.sun = sun;
		const rim = new DirectionalLight(10400968, .4);
		rim.position.set(-4, 6, 12);
		this.scene.add(rim);
		this.scene.add(this.makeSky());
		this.scene.add(this.makeStars());
		this.scene.add(this.makeMoon());
		const abyssGeo = this.trackGeo(new PlaneGeometry(400, 400));
		const abyssMat = this.trackMat(new MeshBasicMaterial({
			color: 460811,
			fog: true
		}));
		const abyss = new Mesh(abyssGeo, abyssMat);
		abyss.rotation.x = -Math.PI / 2;
		abyss.position.y = -.35;
		this.scene.add(abyss);
		const floorGeo = this.trackGeo(new BoxGeometry(7.4, .38, 18.08));
		const floorMat = this.trackMat(mat(2830134, {
			roughness: .82,
			metalness: .04
		}));
		const edgeGeo = this.trackGeo(new BoxGeometry(1.5, .55, 18.08));
		const edgeMat = this.trackMat(mat(1843238, { roughness: .86 }));
		const grooveGeo = this.trackGeo(new BoxGeometry(.16, .05, 18.04));
		const grooveMat = this.trackMat(mat(7259336, {
			emissive: 2789270,
			emissiveIntensity: 1.1,
			roughness: .35
		}));
		const grooveMidMat = this.trackMat(mat(10477794, {
			emissive: 5159100,
			emissiveIntensity: 1.6,
			roughness: .3
		}));
		const cliffGeo = this.trackGeo(new BoxGeometry(3.4, 10, 7.2));
		const cliffMatA = this.trackMat(mat(1711653, { roughness: .9 }));
		const cliffMatB = this.trackMat(mat(2304048, { roughness: .88 }));
		const shardGeo = this.trackGeo(new OctahedronGeometry(.55, 0));
		const shardMat = this.trackMat(mat(8308932, {
			emissive: 2059890,
			emissiveIntensity: .55,
			roughness: .28,
			metalness: .2
		}));
		for (let i = 0; i < SEG_COUNT; i++) {
			const group = new Group();
			const floor = new Mesh(floorGeo, floorMat);
			floor.position.y = -.19;
			floor.receiveShadow = true;
			group.add(floor);
			const leftEdge = new Mesh(edgeGeo, edgeMat);
			leftEdge.position.set(-4.35, -.08, 0);
			leftEdge.receiveShadow = true;
			const rightEdge = new Mesh(edgeGeo, edgeMat);
			rightEdge.position.set(4.35, -.08, 0);
			rightEdge.receiveShadow = true;
			group.add(leftEdge, rightEdge);
			for (let li = 0; li < 3; li++) {
				const g = new Mesh(grooveGeo, li === 1 ? grooveMidMat : grooveMat);
				g.position.set(LANES[li], .03, 0);
				group.add(g);
			}
			const cliffs = [];
			for (const side of [-1, 1]) for (let c = 0; c < 2; c++) {
				const cliff = new Mesh(cliffGeo, c % 2 === 0 ? cliffMatA : cliffMatB);
				cliff.position.set(side * 7.1, 4.4, (c - .5) * 6.2);
				cliff.castShadow = !this.mobile;
				cliff.receiveShadow = true;
				group.add(cliff);
				cliffs.push(cliff);
			}
			const shards = [];
			if (i % 2 === 0) {
				const shard = new Mesh(shardGeo, shardMat);
				shard.position.set((i % 4 === 0 ? -1 : 1) * (9 + Math.random() * 2), 6 + Math.random() * 3, 0);
				shard.userData.spin = .15 + Math.random() * .25;
				group.add(shard);
				shards.push(shard);
			}
			this.scene.add(group);
			this.segments.push({
				group,
				cliffs,
				shards,
				dyn: []
			});
		}
		this.prepPools();
	}
	makeSky() {
		const geo = this.trackGeo(new SphereGeometry(200, 20, 14));
		const colors = [];
		const pos = geo.attributes.position;
		const top = new Color(2766920);
		const bot = new Color(658450);
		const c = new Color();
		for (let i = 0; i < pos.count; i++) {
			const y = pos.getY(i) / 200;
			const t = Math.max(0, Math.min(1, y * .65 + .38));
			c.copy(bot).lerp(top, t);
			colors.push(c.r, c.g, c.b);
		}
		geo.setAttribute("color", new Float32BufferAttribute(colors, 3));
		const skyMat = this.trackMat(new MeshBasicMaterial({
			vertexColors: true,
			side: 1,
			depthWrite: false,
			fog: false
		}));
		return new Mesh(geo, skyMat);
	}
	makeStars() {
		const geo = this.trackGeo(new BufferGeometry());
		const n = 280;
		const arr = new Float32Array(n * 3);
		for (let i = 0; i < n; i++) {
			const theta = Math.random() * Math.PI * 2;
			const phi = Math.acos(.15 + Math.random() * .85);
			const r = 90 + Math.random() * 70;
			arr[i * 3] = r * Math.sin(phi) * Math.cos(theta);
			arr[i * 3 + 1] = r * Math.cos(phi);
			arr[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta) - 40;
		}
		geo.setAttribute("position", new BufferAttribute(arr, 3));
		const matPts = this.trackMat(new PointsMaterial({
			color: 14015972,
			size: .55,
			sizeAttenuation: true,
			transparent: true,
			opacity: .75,
			depthWrite: false,
			fog: false
		}));
		return new Points(geo, matPts);
	}
	makeMoon() {
		const geo = this.trackGeo(new SphereGeometry(5.5, 16, 12));
		const moonMat = this.trackMat(new MeshBasicMaterial({
			color: 15196884,
			fog: false
		}));
		const moon = new Mesh(geo, moonMat);
		moon.position.set(-48, 38, -90);
		return moon;
	}
	prepPools() {
		const crateBody = this.trackGeo(new BoxGeometry(1.45, 1.15, 1.45));
		const crateLid = this.trackGeo(new BoxGeometry(1.52, .12, 1.52));
		const crateMat = this.trackMat(mat(10113862, { roughness: .7 }));
		const crateDark = this.trackMat(mat(7223858, { roughness: .75 }));
		const wallGeo = this.trackGeo(new BoxGeometry(1.7, 2.7, .62));
		const wallMat = this.trackMat(mat(2764856, { roughness: .78 }));
		const crackGeo = this.trackGeo(new BoxGeometry(.1, 2.2, .14));
		const crackMat = this.trackMat(mat(8308932, {
			emissive: 3844264,
			emissiveIntensity: 1.4,
			roughness: .3
		}));
		const orbGeo = this.trackGeo(new OctahedronGeometry(.32, 0));
		const orbMat = this.trackMat(mat(12120300, {
			emissive: 6211776,
			emissiveIntensity: 2.1,
			roughness: .22,
			metalness: .15
		}));
		const haloGeo = this.trackGeo(new SphereGeometry(.55, 10, 8));
		const haloMat = this.trackMat(new MeshBasicMaterial({
			color: 8308932,
			transparent: true,
			opacity: .16,
			depthWrite: false
		}));
		const makeCrate = () => {
			const g = new Group();
			const body = new Mesh(crateBody, crateMat);
			body.position.y = .58;
			body.castShadow = !this.mobile;
			body.receiveShadow = true;
			const lid = new Mesh(crateLid, crateDark);
			lid.position.y = 1.2;
			g.add(body, lid);
			g.visible = false;
			this.scene.add(g);
			return g;
		};
		const makeWall = () => {
			const g = new Group();
			const body = new Mesh(wallGeo, wallMat);
			body.position.y = 1.35;
			body.castShadow = !this.mobile;
			const crack = new Mesh(crackGeo, crackMat);
			crack.position.set(0, 1.35, -.34);
			g.add(body, crack);
			g.visible = false;
			this.scene.add(g);
			return g;
		};
		const makeOrb = () => {
			const g = new Group();
			const core = new Mesh(orbGeo, orbMat);
			const halo = new Mesh(haloGeo, haloMat);
			g.add(core, halo);
			g.visible = false;
			this.scene.add(g);
			return g;
		};
		for (let i = 0; i < 18; i++) this.cratePool.push(makeCrate());
		for (let i = 0; i < 16; i++) this.wallPool.push(makeWall());
		for (let i = 0; i < 24; i++) this.orbPool.push(makeOrb());
	}
	buildPlayer() {
		const bone = this.trackMat(mat(14999768, {
			roughness: .48,
			metalness: .12
		}));
		const ink = this.trackMat(mat(2764083, { roughness: .55 }));
		const visor = this.trackMat(mat(8308932, {
			emissive: 3844272,
			emissiveIntensity: 1.3,
			roughness: .25
		}));
		const courier = new Group();
		const torsoGeo = this.trackGeo(new BoxGeometry(.56, .68, .36));
		const torso = new Mesh(torsoGeo, bone);
		torso.position.y = .98;
		torso.castShadow = !this.mobile;
		courier.add(torso);
		const packGeo = this.trackGeo(new BoxGeometry(.48, .5, .22));
		const pack = new Mesh(packGeo, ink);
		pack.position.set(0, 1.02, .26);
		pack.castShadow = !this.mobile;
		courier.add(pack);
		const stripGeo = this.trackGeo(new BoxGeometry(.18, .42, .04));
		const strip = new Mesh(stripGeo, visor);
		strip.position.set(0, 1.02, .38);
		courier.add(strip);
		const headGeo = this.trackGeo(new SphereGeometry(.22, 12, 10));
		const head = new Mesh(headGeo, bone);
		head.position.y = 1.5;
		head.castShadow = !this.mobile;
		courier.add(head);
		const visorGeo = this.trackGeo(new BoxGeometry(.34, .1, .08));
		const visorMesh = new Mesh(visorGeo, visor);
		visorMesh.position.set(0, 1.5, -.18);
		courier.add(visorMesh);
		const limbGeo = this.trackGeo(new BoxGeometry(.16, .58, .16));
		const armGeo = this.trackGeo(new BoxGeometry(.13, .5, .13));
		const leftLeg = new Group();
		leftLeg.position.set(-.16, .62, 0);
		const ll = new Mesh(limbGeo, ink);
		ll.position.y = -.28;
		ll.castShadow = !this.mobile;
		leftLeg.add(ll);
		const rightLeg = new Group();
		rightLeg.position.set(.16, .62, 0);
		const rl = new Mesh(limbGeo, ink);
		rl.position.y = -.28;
		rl.castShadow = !this.mobile;
		rightLeg.add(rl);
		const leftArm = new Group();
		leftArm.position.set(-.38, 1.18, 0);
		const la = new Mesh(armGeo, bone);
		la.position.y = -.22;
		leftArm.add(la);
		const rightArm = new Group();
		rightArm.position.set(.38, 1.18, 0);
		const ra = new Mesh(armGeo, bone);
		ra.position.y = -.22;
		rightArm.add(ra);
		courier.add(leftLeg, rightLeg, leftArm, rightArm);
		this.parts = {
			leftLeg,
			rightLeg,
			leftArm,
			rightArm
		};
		this.courier = courier;
		const lamp = new PointLight(8308932, .9, 8, 2);
		lamp.position.set(0, 1.4, -.4);
		courier.add(lamp);
		this.playerRoot.add(courier);
		this.playerRoot.position.set(0, 0, 0);
		this.scene.add(this.playerRoot);
		const blobGeo = this.trackGeo(new CircleGeometry(.42, 16));
		const blobMat = this.trackMat(new MeshBasicMaterial({
			color: 0,
			transparent: true,
			opacity: .32,
			depthWrite: false
		}));
		const blob = new Mesh(blobGeo, blobMat);
		blob.rotation.x = -Math.PI / 2;
		blob.position.y = .04;
		this.shadowBlob = blob;
		this.scene.add(blob);
	}
	buildParticles() {
		const geo = this.trackGeo(new BoxGeometry(.12, .12, .12));
		const ice = this.trackMat(new MeshBasicMaterial({ color: 10479844 }));
		const rust = this.trackMat(new MeshBasicMaterial({ color: 12868682 }));
		this.iceSpark = ice;
		this.rustSpark = rust;
		for (let i = 0; i < 40; i++) {
			const mesh = new Mesh(geo, i < 24 ? ice : rust);
			mesh.visible = false;
			this.scene.add(mesh);
			this.particles.push({
				mesh,
				vx: 0,
				vy: 0,
				vz: 0,
				life: 0,
				max: 1
			});
		}
	}
	takePool(kind) {
		const m = (kind === "crate" ? this.cratePool : kind === "wall" ? this.wallPool : this.orbPool).pop();
		if (!m) return null;
		m.visible = true;
		return m;
	}
	givePool(kind, mesh) {
		mesh.visible = false;
		mesh.position.set(0, -20, 0);
		(kind === "crate" ? this.cratePool : kind === "wall" ? this.wallPool : this.orbPool).push(mesh);
	}
	layoutSegments(hazards) {
		this.lastHazard = false;
		for (let i = 0; i < this.segments.length; i++) {
			const seg = this.segments[i];
			this.clearDyn(seg);
			seg.group.position.set(0, 0, -i * SEG_LEN);
			this.jitterCliffs(seg);
			const allow = hazards && i >= 2;
			this.populate(seg, allow);
		}
	}
	jitterCliffs(seg) {
		for (const cliff of seg.cliffs) {
			const s = .72 + Math.random() * .55;
			cliff.scale.set(.9 + Math.random() * .25, s, .85 + Math.random() * .3);
			cliff.position.y = 5 * s * .5 + .2;
		}
	}
	clearDyn(seg) {
		for (const d of seg.dyn) {
			d.alive = false;
			this.givePool(d.kind, d.mesh);
		}
		seg.dyn.length = 0;
	}
	addDyn(seg, kind, lane, localZ, baseY) {
		const mesh = this.takePool(kind);
		if (!mesh) return;
		mesh.position.set(LANES[lane + 1], kind === "orb" ? 0 : 0, 0);
		mesh.position.z = 0;
		const item = {
			mesh,
			kind,
			lane,
			localZ,
			baseY,
			phase: Math.random() * Math.PI * 2,
			alive: true
		};
		seg.dyn.push(item);
		this.placeDyn(seg, item, 0);
	}
	placeDyn(seg, item, time) {
		const x = LANES[item.lane + 1];
		const z = seg.group.position.z + item.localZ;
		let y = item.baseY;
		if (item.kind === "orb") {
			y = item.baseY + Math.sin(time * 5 + item.phase) * .12;
			item.mesh.rotation.y = time * 2.2 + item.phase;
			item.mesh.rotation.x = time * .8;
		}
		item.mesh.position.set(x, y, z);
	}
	populate(seg, hazards) {
		this.clearDyn(seg);
		if (!hazards) {
			if (Math.random() < .45) {
				const lane = randLane();
				for (let i = 0; i < 4; i++) this.addDyn(seg, "orb", lane, -6 + i * 2.2, 1.05);
			}
			return;
		}
		if (this.lastHazard) {
			this.lastHazard = false;
			if (Math.random() < .55) {
				const lane = randLane();
				for (let i = 0; i < 3; i++) this.addDyn(seg, "orb", lane, -5 + i * 2.4, 1.05);
			}
			return;
		}
		const r = Math.random();
		const z = (Math.random() - .5) * 4;
		if (r < .16) {
			const lane = randLane();
			for (let i = 0; i < 4; i++) this.addDyn(seg, "orb", lane, -6 + i * 2.2, 1.05);
			return;
		}
		if (r < .4) {
			const lane = randLane();
			this.addDyn(seg, "crate", lane, z, 0);
			if (Math.random() < .65) this.addDyn(seg, "orb", lane, z, 2.15);
			this.lastHazard = true;
			return;
		}
		if (r < .58) {
			this.addDyn(seg, "wall", randLane(), z, 0);
			this.lastHazard = true;
			return;
		}
		if (r < .78) {
			const open = randLane();
			for (const lane of otherLanes(open)) this.addDyn(seg, "wall", lane, z, 0);
			if (Math.random() < .5) this.addDyn(seg, "orb", open, z, 1.05);
			this.lastHazard = true;
			return;
		}
		if (r < .9) {
			for (const lane of [
				-1,
				0,
				1
			]) {
				this.addDyn(seg, "crate", lane, z, 0);
				if (Math.random() < .4) this.addDyn(seg, "orb", lane, z, 2.15);
			}
			this.lastHazard = true;
			return;
		}
		const lane = randLane();
		this.addDyn(seg, "crate", lane, z, 0);
		this.addDyn(seg, "wall", lane === 0 ? 1 : 0, z - .2, 0);
		this.lastHazard = true;
	}
	resetRun(hazards) {
		this.speed = BASE_SPEED;
		this.distance = 0;
		this.coins = 0;
		this.combo = 0;
		this.comboTimer = 0;
		this.score = 0;
		this.lane = 0;
		this.fromLane = 0;
		this.toLane = 0;
		this.laneT = 1;
		this.queued = 0;
		this.hop = 0;
		this.vy = 0;
		this.grounded = true;
		this.coyote = 0;
		this.jumpBuf = 0;
		this.playerX = 0;
		this.playerRoot.position.set(0, 0, 0);
		this.acc = 0;
		this.trauma = 0;
		this.hitstop = 0;
		this.layoutSegments(hazards);
	}
	bind() {
		window.addEventListener("keydown", this.onKeyDown, { passive: false });
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.onBlur);
		document.addEventListener("visibilitychange", this.onVis);
		window.addEventListener("pointerdown", this.onPointerDown);
		window.addEventListener("pointerup", this.onPointerUp);
		window.addEventListener("pointercancel", this.onPointerCancel);
		window.addEventListener("resize", this.onResize);
		window.addEventListener("orientationchange", this.onResize);
		this.ro = new ResizeObserver(() => this.resize());
		const parent = this.canvas.parentElement ?? this.canvas;
		this.ro.observe(parent);
	}
	unbind() {
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.onBlur);
		document.removeEventListener("visibilitychange", this.onVis);
		window.removeEventListener("pointerdown", this.onPointerDown);
		window.removeEventListener("pointerup", this.onPointerUp);
		window.removeEventListener("pointercancel", this.onPointerCancel);
		window.removeEventListener("resize", this.onResize);
		window.removeEventListener("orientationchange", this.onResize);
	}
	handleKey(e, down) {
		const code = e.code;
		if (code === "Space" || code === "ArrowLeft" || code === "ArrowRight" || code === "ArrowUp" || code === "KeyA" || code === "KeyD" || code === "KeyW" || code === "Enter") e.preventDefault();
		if (down) this.keys.add(code);
		else this.keys.delete(code);
		if (down && (code === "Space" || code === "Enter") && this.state !== "playing") {
			this.start();
			this.prevHeld.add(code);
			return;
		}
	}
	ptrDown(e) {
		if (e.target?.closest?.("[data-ui]")) return;
		this.pointers.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}
	ptrUp(e) {
		const start = this.pointers.get(e.pointerId);
		this.pointers.delete(e.pointerId);
		if (!start) return;
		if (e.target?.closest?.("[data-ui]")) return;
		if (this.state !== "playing") {
			this.start();
			return;
		}
		const dx = e.clientX - start.x;
		const dy = e.clientY - start.y;
		if (Math.hypot(dx, dy) < 28) {
			this.jumpBuf = .14;
			return;
		}
		if (Math.abs(dx) > Math.abs(dy)) this.trySwitch(dx < 0 ? -1 : 1);
		else if (dy < 0) this.jumpBuf = .14;
	}
	held() {
		if (this.injected.size === 0) return this.keys;
		const s = new Set(this.keys);
		for (const c of this.injected) s.add(c);
		return s;
	}
	trySwitch(dir) {
		if (this.state === "start") return;
		const next = (this.laneT < 1 ? this.toLane : this.lane) + dir;
		if (next < -1 || next > 1) return;
		if (this.laneT < 1) {
			this.queued = dir;
			return;
		}
		this.fromLane = this.lane;
		this.toLane = next;
		this.laneT = 0;
		this.audio.unlock();
		this.audio.lane();
	}
	consumeInput() {
		const held = this.held();
		const just = (code) => held.has(code) && !this.prevHeld.has(code);
		if (just("KeyA") || just("ArrowLeft")) this.trySwitch(-1);
		if (just("KeyD") || just("ArrowRight")) this.trySwitch(1);
		if (just("Space") || just("ArrowUp")) this.jumpBuf = .14;
		if (this.steerInject > .5 && this.prevSteer <= .5) this.trySwitch(-1);
		if (this.steerInject < -.5 && this.prevSteer >= -.5) this.trySwitch(1);
		this.prevSteer = this.steerInject;
		this.prevHeld = new Set(held);
	}
	step(dt) {
		this.consumeInput();
		if (this.hitstop > 0) {
			this.hitstop -= dt;
			return;
		}
		if (this.state === "over") return;
		const scrolling = this.state === "playing" || this.state === "start";
		const spd = this.state === "playing" ? this.speed : 5.5;
		if (!scrolling) return;
		if (this.state === "playing") {
			this.speed = Math.min(MAX_SPEED, this.speed + SPEED_RAMP * dt);
			this.distance += this.speed * dt;
			this.score = Math.floor(this.distance * 10) + this.coins * 40;
			this.comboTimer -= dt;
			if (this.comboTimer <= 0) this.combo = 0;
		}
		for (const seg of this.segments) {
			seg.group.position.z += spd * dt;
			if (seg.group.position.z > RECYCLE_Z) {
				seg.group.position.z -= 216;
				this.jitterCliffs(seg);
				this.populate(seg, this.state === "playing");
			}
			for (const d of seg.dyn) if (d.alive) this.placeDyn(seg, d, this.time);
		}
		if (this.laneT < 1) {
			this.laneT = Math.min(1, this.laneT + dt / LANE_TIME);
			const t = easeOutCubic(this.laneT);
			this.playerX = LANES[this.fromLane + 1] + (LANES[this.toLane + 1] - LANES[this.fromLane + 1]) * t;
			if (this.laneT >= 1) {
				this.lane = this.toLane;
				this.playerX = LANES[this.lane + 1];
				if (this.queued) {
					const dir = this.queued;
					this.queued = 0;
					this.trySwitch(dir);
				}
			}
		}
		this.jumpBuf = Math.max(0, this.jumpBuf - dt);
		this.coyote = Math.max(0, this.coyote - dt);
		const canJump = this.grounded || this.coyote > 0;
		if (this.jumpBuf > 0 && canJump && this.state === "playing") {
			this.vy = JUMP_V;
			this.grounded = false;
			this.coyote = 0;
			this.jumpBuf = 0;
			this.audio.jump();
		}
		if (!this.grounded || this.vy > 0) {
			this.vy -= GRAVITY * dt;
			this.hop += this.vy * dt;
			if (this.hop <= 0) {
				this.hop = 0;
				if (this.vy < -4) this.burst(this.playerX, .2, 0, "land");
				this.vy = 0;
				this.grounded = true;
			}
		}
		if (this.grounded) this.coyote = .09;
		this.playerRoot.position.x = this.playerX;
		this.playerRoot.position.y = this.hop;
		this.playerRoot.position.z = 0;
		if (this.state === "playing") this.collide();
	}
	collide() {
		const px = this.playerX;
		const py = .78 + this.hop;
		const pz = 0;
		const phx = .3;
		const phy = .7;
		const phz = .32;
		for (const seg of this.segments) for (const d of seg.dyn) {
			if (!d.alive) continue;
			const ox = LANES[d.lane + 1];
			const oz = seg.group.position.z + d.localZ;
			if (d.kind === "orb") {
				const oy = d.baseY;
				if (Math.abs(px - ox) < .7 && Math.abs(pz - oz) < .7 && Math.abs(py - oy) < .9) {
					d.alive = false;
					this.givePool("orb", d.mesh);
					this.combo += 1;
					this.comboTimer = 1.4;
					this.coins += 1;
					this.score = Math.floor(this.distance * 10) + this.coins * 40 + Math.max(0, this.combo - 1) * 8;
					this.audio.coin(this.combo);
					this.burst(ox, oy, oz, "ice");
				}
				continue;
			}
			const hx = d.kind === "crate" ? .72 : .82;
			const hy = d.kind === "crate" ? .58 : 1.32;
			const hz = d.kind === "crate" ? .72 : .36;
			const oy = d.kind === "crate" ? .58 : 1.35;
			if (Math.abs(px - ox) < phx + hx && Math.abs(py - oy) < phy + hy && Math.abs(pz - oz) < phz + hz) {
				this.crash();
				return;
			}
		}
	}
	crash() {
		this.state = "over";
		this.trauma = this.reduceMotion ? .15 : 1;
		this.hitstop = .1;
		this.audio.crash();
		this.audio.stopDrone();
		this.burst(this.playerX, .9 + this.hop, 0, "rust");
		if (this.score > this.best) {
			this.best = this.score;
			writeBest(this.best);
		}
		this.emit();
	}
	burst(x, y, z, kind) {
		let n = kind === "land" ? 6 : 12;
		for (const p of this.particles) {
			if (p.life > 0) continue;
			p.mesh.material = kind === "rust" ? this.rustSpark : this.iceSpark;
			p.mesh.visible = true;
			p.mesh.position.set(x, y, z);
			p.vx = (Math.random() - .5) * (kind === "land" ? 2.2 : 5);
			p.vy = Math.random() * (kind === "land" ? 2 : 5) + 1;
			p.vz = (Math.random() - .5) * (kind === "land" ? 1.4 : 4);
			p.max = .35 + Math.random() * .25;
			p.life = p.max;
			n -= 1;
			if (n <= 0) break;
		}
	}
	animateCourier(dt) {
		const parts = this.parts;
		if (!parts) return;
		const spd = this.state === "over" ? 0 : this.state === "playing" ? this.speed : 5.5;
		if (this.hop > .04) {
			parts.leftLeg.rotation.x = -.45;
			parts.rightLeg.rotation.x = .25;
			parts.leftArm.rotation.x = .35;
			parts.rightArm.rotation.x = -.45;
			const stretch = this.reduceMotion ? 1 : 1 + Math.min(.18, this.vy * .02);
			this.courier.scale.set(1 / Math.sqrt(stretch), stretch, 1 / Math.sqrt(stretch));
		} else {
			this.runPhase += dt * (8 + spd * .22);
			const s = Math.sin(this.runPhase);
			parts.leftLeg.rotation.x = s * .7;
			parts.rightLeg.rotation.x = -s * .7;
			parts.leftArm.rotation.x = -s * .5;
			parts.rightArm.rotation.x = s * .5;
			const landSquash = this.reduceMotion ? 1 : 1 - Math.min(.12, Math.abs(this.vy) * .01);
			this.courier.scale.set(1 / landSquash, landSquash, 1 / landSquash);
			this.courier.position.y = Math.abs(Math.sin(this.runPhase * 2)) * .035;
		}
		if (this.shadowBlob) {
			this.shadowBlob.position.x = this.playerX;
			this.shadowBlob.position.z = 0;
			const k = Math.max(.25, 1 - this.hop * .45);
			this.shadowBlob.scale.setScalar(k);
			const m = this.shadowBlob.material;
			m.opacity = .3 * k;
		}
	}
	updateCamera(dt) {
		const lookAhead = this.state === "playing" ? 8 : 6;
		const desiredX = this.playerX * .32;
		const desiredY = 3.55 + this.hop * .12;
		const desiredZ = 8.1;
		this.camera.position.x = expDamp(this.camera.position.x, desiredX, 6, dt);
		this.camera.position.y = expDamp(this.camera.position.y, desiredY, 5.5, dt);
		this.camera.position.z = expDamp(this.camera.position.z, desiredZ, 5, dt);
		if (this.trauma > 0 && !this.reduceMotion) {
			this.trauma = Math.max(0, this.trauma - dt * 2.8);
			const mag = this.trauma * this.trauma * .45;
			this.camera.position.x += (Math.random() - .5) * mag;
			this.camera.position.y += (Math.random() - .5) * mag * .6;
		}
		_world.set(this.playerX * .65, 1.15 + this.hop * .25, -lookAhead);
		this.camera.lookAt(_world);
		const roll = MathUtils.clamp(-this.playerX * .012, -.06, .06);
		this.camera.rotateZ(roll);
		if (this.sun) {
			this.sun.position.set(8 + this.playerX * .2, 22, 8);
			this.sun.target.position.set(this.playerX, 0, -12);
		}
	}
	updateParticles(dt) {
		for (const p of this.particles) {
			if (p.life <= 0) {
				if (p.mesh.visible) p.mesh.visible = false;
				continue;
			}
			p.life -= dt;
			p.vy -= 14 * dt;
			p.mesh.position.x += p.vx * dt;
			p.mesh.position.y += p.vy * dt;
			p.mesh.position.z += p.vz * dt;
			const s = Math.max(.05, p.life / p.max);
			p.mesh.scale.setScalar(s);
			if (p.life <= 0) p.mesh.visible = false;
		}
	}
	frame = (now) => {
		if (!this.running || !this.renderer) return;
		const dtRaw = Math.min(.1, this._last ? (now - this._last) / 1e3 : FIXED);
		this._last = now;
		this.time += dtRaw;
		this.acc += dtRaw;
		let steps = 0;
		while (this.acc >= FIXED && steps < 7) {
			this.step(FIXED);
			this.acc -= FIXED;
			steps += 1;
		}
		this.animateCourier(dtRaw);
		this.updateCamera(dtRaw);
		this.updateParticles(dtRaw);
		for (const seg of this.segments) for (const shard of seg.shards) {
			shard.rotation.y += dtRaw * shard.userData.spin;
			shard.rotation.z += dtRaw * .08;
		}
		this.renderer.render(this.scene, this.camera);
		this.emitSoft();
	};
	_last = 0;
	resize() {
		if (!this.renderer) return;
		const parent = this.canvas.parentElement ?? this.canvas;
		const w = Math.max(1, parent.clientWidth);
		const h = Math.max(1, parent.clientHeight);
		this.camera.aspect = w / h;
		this.camera.updateProjectionMatrix();
		this.renderer.setSize(w, h, false);
	}
	snapshot() {
		return {
			state: this.state,
			score: this.score,
			distance: this.distance,
			coins: this.coins,
			combo: this.combo,
			best: this.best,
			muted: this.muted,
			webgl: !this.failed
		};
	}
	emit() {
		const snap = this.snapshot();
		this.lastEmit = `${snap.state}|${snap.score}|${snap.coins}|${snap.combo}|${snap.muted}|${snap.best}`;
		this.onChange(snap);
	}
	emitSoft() {
		if (this.state !== "playing") return;
		const key = `${this.state}|${this.score}|${this.coins}|${this.combo}|${this.muted}|${this.best}`;
		if (key === this.lastEmit) return;
		this.lastEmit = key;
		this.onChange(this.snapshot());
	}
	hookControlsTest() {
		window.__controlsTest = {
			getYaw: () => -this.playerX,
			getSpeed: () => this.state === "playing" ? this.speed : 0,
			setKeys: (codes) => {
				this.injected = new Set(codes);
			},
			setSteer: (v) => {
				this.steerInject = v;
			}
		};
	}
};
//#endregion
export { INITIAL_SNAP, RunnerGame };
