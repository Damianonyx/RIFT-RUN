import { i as __toESM } from "../_runtime.mjs";
import { I as require_jsx_runtime, L as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ChevronLeft, i as ChevronRight, n as Volume2, o as ArrowUp, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CX81ekbU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var INITIAL_SNAP = {
	state: "start",
	score: 0,
	distance: 0,
	coins: 0,
	combo: 0,
	best: 0,
	muted: false,
	webgl: true
};
var enginePromise = import("./engine-Q4oWkSUX.mjs");
function GameScreen() {
	const canvasRef = (0, import_react.useRef)(null);
	const gameRef = (0, import_react.useRef)(null);
	const pendingStart = (0, import_react.useRef)(false);
	const [snap, setSnap] = (0, import_react.useState)(INITIAL_SNAP);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [loadError, setLoadError] = (0, import_react.useState)(null);
	const [starting, setStarting] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!canvasRef.current) return;
		let cancelled = false;
		let game = null;
		enginePromise.then(({ RunnerGame }) => {
			if (cancelled) return;
			const el = canvasRef.current;
			if (!el) return;
			game = new RunnerGame(el, (next) => {
				setSnap(next);
			});
			if (cancelled) {
				game.dispose();
				return;
			}
			gameRef.current = game;
			setReady(true);
			if (pendingStart.current) {
				pendingStart.current = false;
				game.start();
			}
		}).catch((err) => {
			if (cancelled) return;
			const msg = err instanceof Error ? err.message : "The 3D engine failed to load.";
			setLoadError(msg);
		});
		return () => {
			cancelled = true;
			game?.dispose();
			gameRef.current = null;
		};
	}, []);
	const start = (0, import_react.useCallback)(() => {
		const g = gameRef.current;
		if (g) {
			try {
				g.start();
			} catch {
				pendingStart.current = true;
				setStarting(true);
			}
			return;
		}
		pendingStart.current = true;
		setStarting(true);
	}, []);
	const mute = (0, import_react.useCallback)(() => {
		gameRef.current?.toggleMuted();
	}, []);
	const lane = (0, import_react.useCallback)((dir) => {
		gameRef.current?.queueLane(dir);
	}, []);
	const jump = (0, import_react.useCallback)(() => {
		gameRef.current?.queueJump();
	}, []);
	const retry = (0, import_react.useCallback)(() => {
		window.location.reload();
	}, []);
	const playing = snap.state === "playing";
	const overlay = snap.state !== "playing";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-[100dvh] min-h-[100svh] w-full overflow-hidden bg-bg text-fg antialiased select-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 block h-full w-full touch-none"
			}),
			!snap.webgl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-center justify-center bg-bg p-6 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-fg",
							children: "This browser blocked WebGL, so the run cannot start."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Try Safari or Chrome, or close other tabs and reload."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"data-ui": true,
							onPointerDown: (e) => {
								e.preventDefault();
								retry();
							},
							onClick: retry,
							className: "mt-5 h-12 w-full rounded-lg bg-accent px-5 text-sm font-medium tracking-wide text-accent-fg",
							style: { touchAction: "manipulation" },
							children: "Reload"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-0 z-10 flex flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex items-start justify-between gap-3 p-4 pt-[max(1rem,env(safe-area-inset-top))] sm:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: playing || snap.state === "over" ? "opacity-100" : "opacity-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[0.6875rem] font-medium tracking-[0.22em] text-muted uppercase",
									children: "Score"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl leading-none font-semibold tracking-tight tabular-nums sm:text-4xl",
									children: snap.score
								}),
								snap.combo > 1 && playing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-xs tracking-wide text-ice tabular-nums",
									children: [
										"x",
										snap.combo,
										" streak"
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[0.6875rem] font-medium tracking-[0.22em] text-muted uppercase",
									children: "Best"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-xl leading-none font-medium tracking-tight text-fg/90 tabular-nums",
									children: snap.best
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PressBtn, {
								label: snap.muted ? "Unmute" : "Mute",
								onPress: mute,
								className: "size-11 rounded-lg border border-border bg-surface text-fg hover:bg-surface-2",
								children: snap.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {
									className: "size-5",
									strokeWidth: 1.75
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
									className: "size-5",
									strokeWidth: 1.75
								})
							})]
						})]
					}),
					overlay && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-1 items-center justify-center px-4 pb-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							"data-ui": true,
							className: "pointer-events-auto w-full max-w-md rounded-2xl border border-border bg-surface/92 p-6 shadow-[0_24px_60px_rgba(0,0,0,0.45)] sm:p-7",
							style: { touchAction: "manipulation" },
							children: snap.state === "start" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StartPanel, {
								best: snap.best,
								onStart: start,
								onRetry: retry,
								starting: starting && !ready,
								loadError
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverPanel, {
								score: snap.score,
								best: snap.best,
								onStart: start
							})
						})
					}),
					playing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto flex items-end justify-between gap-3 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] md:hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchBtn, {
								label: "Lane left",
								onPress: () => lane(-1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
									className: "size-7",
									strokeWidth: 1.75
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TouchBtn, {
								label: "Jump",
								wide: true,
								onPress: jump,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, {
									className: "size-7",
									strokeWidth: 1.75
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[0.6875rem] font-medium tracking-[0.18em] uppercase",
									children: "Jump"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchBtn, {
								label: "Lane right",
								onPress: () => lane(1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
									className: "size-7",
									strokeWidth: 1.75
								})
							})
						]
					})
				]
			})
		]
	});
}
function StartPanel({ best, onStart, onRetry, starting, loadError }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[0.6875rem] font-medium tracking-[0.28em] text-muted uppercase",
						children: "Endless runner"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-5xl leading-[0.95] font-semibold tracking-tight text-balance sm:text-6xl",
						children: "Rift Run"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-pretty text-muted",
						children: "Three lanes of fractured stone. Switch, jump, and gather rift light before the walls close in."
					})
				]
			}),
			loadError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: loadError
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PressBtn, {
				label: "Reload",
				onPress: onRetry,
				className: "h-12 w-full rounded-lg bg-accent text-sm font-medium tracking-wide text-accent-fg",
				children: "Reload"
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PressBtn, {
				label: "Start run",
				onPress: onStart,
				className: "h-12 w-full rounded-lg bg-accent text-sm font-medium tracking-wide text-accent-fg",
				children: starting ? "Starting…" : "Start run"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-1.5 text-sm text-faint",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-fg/80",
						children: "A / D"
					}), " or arrows — change lane"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-fg/80",
						children: "Space"
					}), " — jump crates"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "md:hidden",
						children: "Tap Start, then swipe left, right, or up"
					})
				]
			}),
			best > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs tracking-wide text-muted uppercase",
				children: ["Best ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-fg tabular-nums",
					children: best
				})]
			})
		]
	});
}
function OverPanel({ score, best, onStart }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[0.6875rem] font-medium tracking-[0.28em] text-muted uppercase",
					children: "Run over"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl leading-none font-semibold tracking-tight",
					children: "Rift Run"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Score",
					value: score
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: score > 0 && score >= best ? "New best" : "Best",
					value: best
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PressBtn, {
				label: "Run again",
				onPress: onStart,
				className: "h-12 w-full rounded-lg bg-accent text-sm font-medium tracking-wide text-accent-fg",
				children: "Run again"
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[0.6875rem] font-medium tracking-[0.22em] text-muted uppercase",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-display text-3xl font-semibold tracking-tight tabular-nums",
		children: value
	})] });
}
function PressBtn({ label, onPress, className, children }) {
	const last = (0, import_react.useRef)(0);
	const fire = () => {
		const now = performance.now();
		if (now - last.current < 350) return;
		last.current = now;
		onPress();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"data-ui": true,
		"aria-label": label,
		onClick: (e) => {
			e.stopPropagation();
			fire();
		},
		onPointerUp: (e) => {
			if (e.pointerType === "mouse") return;
			e.stopPropagation();
			fire();
		},
		className: "pointer-events-auto flex items-center justify-center transition-transform duration-150 hover:opacity-90 active:scale-[0.98] " + className,
		style: { touchAction: "manipulation" },
		children
	});
}
function TouchBtn({ label, onPress, children, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"data-ui": true,
		"aria-label": label,
		onPointerDown: (e) => {
			e.preventDefault();
			onPress();
		},
		className: "pointer-events-auto flex h-16 items-center justify-center gap-1 rounded-xl border border-border bg-surface/90 text-fg " + (wide ? "min-w-28 flex-1 flex-col" : "w-16"),
		style: { touchAction: "manipulation" },
		children
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameScreen, {});
}
//#endregion
export { INITIAL_SNAP as n, routes_exports as t };
