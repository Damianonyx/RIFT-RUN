//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CvzmCB2J.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-mtTseU0Q.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-mtTseU0Q.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B7RNzuJ-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
